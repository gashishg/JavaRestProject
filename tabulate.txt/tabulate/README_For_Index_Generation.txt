This folder contains the main script called : generate_default_index_webpage.sh
and a Search icon called : search.png

1. Copy these two files to the folder, for which you want to generate an index page and
2. Edit the main script with a good Text / Code Editor like "Sublime Text" ( https://www.sublimetext.com/ ) for a few Parameters at the top of the Script. This must match your setup.
3. Save the Script
4. Open Terminal By Right Clicking on this Folder Level and Choosing Open Terminal Here
5. After taking backups, Run the Script by typing ./generate_default_index_webpage.sh  and  press the enter key
6. This will generate the required index page
7. If required, transfer this folder ( including search.png ) to the webserver, after taking backups on the webserver
8. Consult your System Administrator for any queries regarding the transfers

Hope you find the script useful for your work.

Regards,

Nathan SR 
