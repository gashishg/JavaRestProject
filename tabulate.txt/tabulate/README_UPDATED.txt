
Project Website : 

https://sourceforge.net/projects/command-output-to-html-table/

Please refer the above website for usage instructions and examples.

Also, check its wiki page for advanced examples, to gain more expertise.

This zip file contains the main script called tabulate.sh and a search icon called search.png. This icon needs to be copied to the location, where you are storing / uploading your generated output html file. 

Also, this zip file needs to be extracted first to a folder, before viewing / working with its files.

Samples of input files (.xlsx with formulas and csv) and output files (html) are provided in this zip file.

Also, included are Server* files, useful for working on Servers with Automated Scripting.
The Server_Sample_Code_For_Scripts.sh contains documentation at the top of the file.
View this script with a good text / code editor.
This script does what the .xlsx sheet was doing with its formulas, but on the Server Side (without GUI but automated).

Also, included is a script called : generate_default_index_webpage.sh  along with its own README file.

With this, the job opportunities multiply for those willing to take up work on the Server / Client Side.

Hope, you find this script, very useful for your work.

I would like to hear your feedback on the same.

Regards,

Nathan SR

linuxguist@gmail.com



P.S. Now the main script is updated to provide compatibility with very old browsers and can handle all html syntax directly.
